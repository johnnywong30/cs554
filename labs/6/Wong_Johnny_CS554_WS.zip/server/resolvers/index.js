const Query = require('./query')

const resolvers = {
    Query
}

module.exports = resolvers