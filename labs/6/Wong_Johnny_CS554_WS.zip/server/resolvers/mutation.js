const { client } = require('../redis');
const { v4: uuidv4 } = require('uuid')

const Mutation = {

}

module.exports = Mutation