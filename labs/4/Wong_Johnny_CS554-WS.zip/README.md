# CS554-WS Lab 4

### Author: Johnny Wong 10446964

### Pledge I pledge my honor that I have abided by the Stevens Honor System.

## How to Run

### Install Dependencies

1. `cd client`
2. `npm i`
3. `cd ../server`
4. `npm i`

### Start Client & Server

1. `cd client`
2. `npm start`
   In another terminal:
3. `cd server`
4. `npm start`

Should be able to view my lab 4 now on `localhost:3000`
